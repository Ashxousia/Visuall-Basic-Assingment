﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NewAccount
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.txtPhysicaladdress = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtTelephone = New System.Windows.Forms.TextBox()
        Me.txtDOB = New System.Windows.Forms.DateTimePicker()
        Me.lbl6 = New System.Windows.Forms.Label()
        Me.grp1 = New System.Windows.Forms.GroupBox()
        Me.radFemale = New System.Windows.Forms.RadioButton()
        Me.radMale = New System.Windows.Forms.RadioButton()
        Me.lbl7 = New System.Windows.Forms.Label()
        Me.txtPosition = New System.Windows.Forms.TextBox()
        Me.lbl8 = New System.Windows.Forms.Label()
        Me.txtBranch = New System.Windows.Forms.TextBox()
        Me.cmb1 = New System.Windows.Forms.ComboBox()
        Me.lbl10 = New System.Windows.Forms.Label()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.cmb2 = New System.Windows.Forms.ComboBox()
        Me.lbl11 = New System.Windows.Forms.Label()
        Me.txtEmployeeNumber = New System.Windows.Forms.TextBox()
        Me.txtdatee = New System.Windows.Forms.DateTimePicker()
        Me.lbl12 = New System.Windows.Forms.Label()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.grp1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Location = New System.Drawing.Point(18, 25)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(35, 13)
        Me.lbl1.TabIndex = 0
        Me.lbl1.Text = "Name"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(119, 25)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 1
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(18, 82)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(49, 13)
        Me.lbl2.TabIndex = 2
        Me.lbl2.Text = "Surname"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Location = New System.Drawing.Point(18, 138)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(86, 13)
        Me.lbl3.TabIndex = 3
        Me.lbl3.Text = "Physical address"
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Location = New System.Drawing.Point(18, 193)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(38, 13)
        Me.lbl4.TabIndex = 4
        Me.lbl4.Text = "E mail "
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.Location = New System.Drawing.Point(18, 244)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(58, 13)
        Me.lbl5.TabIndex = 5
        Me.lbl5.Text = "Telephone"
        '
        'txtSurname
        '
        Me.txtSurname.Location = New System.Drawing.Point(119, 82)
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.Size = New System.Drawing.Size(100, 20)
        Me.txtSurname.TabIndex = 6
        '
        'txtPhysicaladdress
        '
        Me.txtPhysicaladdress.Location = New System.Drawing.Point(119, 138)
        Me.txtPhysicaladdress.Name = "txtPhysicaladdress"
        Me.txtPhysicaladdress.Size = New System.Drawing.Size(100, 20)
        Me.txtPhysicaladdress.TabIndex = 7
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(119, 193)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(100, 20)
        Me.txtEmail.TabIndex = 8
        '
        'txtTelephone
        '
        Me.txtTelephone.Location = New System.Drawing.Point(119, 244)
        Me.txtTelephone.Name = "txtTelephone"
        Me.txtTelephone.Size = New System.Drawing.Size(100, 20)
        Me.txtTelephone.TabIndex = 9
        '
        'txtDOB
        '
        Me.txtDOB.Location = New System.Drawing.Point(103, 317)
        Me.txtDOB.Name = "txtDOB"
        Me.txtDOB.Size = New System.Drawing.Size(200, 20)
        Me.txtDOB.TabIndex = 10
        '
        'lbl6
        '
        Me.lbl6.AutoSize = True
        Me.lbl6.Location = New System.Drawing.Point(18, 317)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(66, 13)
        Me.lbl6.TabIndex = 11
        Me.lbl6.Text = "Date of Birth"
        '
        'grp1
        '
        Me.grp1.Controls.Add(Me.radFemale)
        Me.grp1.Controls.Add(Me.radMale)
        Me.grp1.Location = New System.Drawing.Point(340, 244)
        Me.grp1.Name = "grp1"
        Me.grp1.Size = New System.Drawing.Size(200, 100)
        Me.grp1.TabIndex = 12
        Me.grp1.TabStop = False
        Me.grp1.Text = "Gender"
        '
        'radFemale
        '
        Me.radFemale.AutoSize = True
        Me.radFemale.Location = New System.Drawing.Point(18, 77)
        Me.radFemale.Name = "radFemale"
        Me.radFemale.Size = New System.Drawing.Size(59, 17)
        Me.radFemale.TabIndex = 1
        Me.radFemale.TabStop = True
        Me.radFemale.Text = "Female"
        Me.radFemale.UseVisualStyleBackColor = True
        '
        'radMale
        '
        Me.radMale.AutoSize = True
        Me.radMale.Location = New System.Drawing.Point(18, 31)
        Me.radMale.Name = "radMale"
        Me.radMale.Size = New System.Drawing.Size(48, 17)
        Me.radMale.TabIndex = 0
        Me.radMale.TabStop = True
        Me.radMale.Text = "Male"
        Me.radMale.UseVisualStyleBackColor = True
        '
        'lbl7
        '
        Me.lbl7.AutoSize = True
        Me.lbl7.Location = New System.Drawing.Point(18, 383)
        Me.lbl7.Name = "lbl7"
        Me.lbl7.Size = New System.Drawing.Size(44, 13)
        Me.lbl7.TabIndex = 13
        Me.lbl7.Text = "Position"
        '
        'txtPosition
        '
        Me.txtPosition.Location = New System.Drawing.Point(119, 384)
        Me.txtPosition.Name = "txtPosition"
        Me.txtPosition.Size = New System.Drawing.Size(100, 20)
        Me.txtPosition.TabIndex = 14
        '
        'lbl8
        '
        Me.lbl8.AutoSize = True
        Me.lbl8.Location = New System.Drawing.Point(306, 383)
        Me.lbl8.Name = "lbl8"
        Me.lbl8.Size = New System.Drawing.Size(41, 13)
        Me.lbl8.TabIndex = 15
        Me.lbl8.Text = "Branch"
        '
        'txtBranch
        '
        Me.txtBranch.Location = New System.Drawing.Point(418, 383)
        Me.txtBranch.Name = "txtBranch"
        Me.txtBranch.Size = New System.Drawing.Size(100, 20)
        Me.txtBranch.TabIndex = 16
        '
        'cmb1
        '
        Me.cmb1.FormattingEnabled = True
        Me.cmb1.Items.AddRange(New Object() {"Contract", "Permanent"})
        Me.cmb1.Location = New System.Drawing.Point(21, 453)
        Me.cmb1.Name = "cmb1"
        Me.cmb1.Size = New System.Drawing.Size(121, 21)
        Me.cmb1.TabIndex = 17
        Me.cmb1.Text = "Employment Status"
        '
        'lbl10
        '
        Me.lbl10.AutoSize = True
        Me.lbl10.Location = New System.Drawing.Point(306, 453)
        Me.lbl10.Name = "lbl10"
        Me.lbl10.Size = New System.Drawing.Size(24, 13)
        Me.lbl10.TabIndex = 19
        Me.lbl10.Text = "City"
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(418, 446)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(100, 20)
        Me.txtCity.TabIndex = 21
        '
        'cmb2
        '
        Me.cmb2.FormattingEnabled = True
        Me.cmb2.Items.AddRange(New Object() {"Botswana", "South Africa", "Zambia", "Zimbabwe"})
        Me.cmb2.Location = New System.Drawing.Point(21, 510)
        Me.cmb2.Name = "cmb2"
        Me.cmb2.Size = New System.Drawing.Size(121, 21)
        Me.cmb2.TabIndex = 22
        Me.cmb2.Text = "Select Country"
        '
        'lbl11
        '
        Me.lbl11.AutoSize = True
        Me.lbl11.Location = New System.Drawing.Point(306, 491)
        Me.lbl11.Name = "lbl11"
        Me.lbl11.Size = New System.Drawing.Size(93, 13)
        Me.lbl11.TabIndex = 23
        Me.lbl11.Text = "Employee Number"
        '
        'txtEmployeeNumber
        '
        Me.txtEmployeeNumber.Location = New System.Drawing.Point(418, 491)
        Me.txtEmployeeNumber.Name = "txtEmployeeNumber"
        Me.txtEmployeeNumber.Size = New System.Drawing.Size(100, 20)
        Me.txtEmployeeNumber.TabIndex = 24
        '
        'txtdatee
        '
        Me.txtdatee.Location = New System.Drawing.Point(82, 557)
        Me.txtdatee.Name = "txtdatee"
        Me.txtdatee.Size = New System.Drawing.Size(200, 20)
        Me.txtdatee.TabIndex = 25
        '
        'lbl12
        '
        Me.lbl12.AutoSize = True
        Me.lbl12.Location = New System.Drawing.Point(18, 557)
        Me.lbl12.Name = "lbl12"
        Me.lbl12.Size = New System.Drawing.Size(36, 13)
        Me.lbl12.TabIndex = 26
        Me.lbl12.Text = "Datee"
        '
        'btn1
        '
        Me.btn1.Location = New System.Drawing.Point(255, 629)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(75, 23)
        Me.btn1.TabIndex = 27
        Me.btn1.Text = "Submit"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'NewAccount
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(566, 651)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.lbl12)
        Me.Controls.Add(Me.txtdatee)
        Me.Controls.Add(Me.txtEmployeeNumber)
        Me.Controls.Add(Me.lbl11)
        Me.Controls.Add(Me.cmb2)
        Me.Controls.Add(Me.txtCity)
        Me.Controls.Add(Me.lbl10)
        Me.Controls.Add(Me.cmb1)
        Me.Controls.Add(Me.txtBranch)
        Me.Controls.Add(Me.lbl8)
        Me.Controls.Add(Me.txtPosition)
        Me.Controls.Add(Me.lbl7)
        Me.Controls.Add(Me.grp1)
        Me.Controls.Add(Me.lbl6)
        Me.Controls.Add(Me.txtDOB)
        Me.Controls.Add(Me.txtTelephone)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.txtPhysicaladdress)
        Me.Controls.Add(Me.txtSurname)
        Me.Controls.Add(Me.lbl5)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lbl1)
        Me.Name = "NewAccount"
        Me.Text = "NewAccount"
        Me.grp1.ResumeLayout(False)
        Me.grp1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents lbl3 As System.Windows.Forms.Label
    Friend WithEvents lbl4 As System.Windows.Forms.Label
    Friend WithEvents lbl5 As System.Windows.Forms.Label
    Friend WithEvents txtSurname As System.Windows.Forms.TextBox
    Friend WithEvents txtPhysicaladdress As System.Windows.Forms.TextBox
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtTelephone As System.Windows.Forms.TextBox
    Friend WithEvents txtDOB As System.Windows.Forms.DateTimePicker
    Friend WithEvents lbl6 As System.Windows.Forms.Label
    Friend WithEvents grp1 As System.Windows.Forms.GroupBox
    Friend WithEvents radFemale As System.Windows.Forms.RadioButton
    Friend WithEvents radMale As System.Windows.Forms.RadioButton
    Friend WithEvents lbl7 As System.Windows.Forms.Label
    Friend WithEvents txtPosition As System.Windows.Forms.TextBox
    Friend WithEvents lbl8 As System.Windows.Forms.Label
    Friend WithEvents txtBranch As System.Windows.Forms.TextBox
    Friend WithEvents cmb1 As System.Windows.Forms.ComboBox
    Friend WithEvents lbl10 As System.Windows.Forms.Label
    Friend WithEvents txtCity As System.Windows.Forms.TextBox
    Friend WithEvents cmb2 As System.Windows.Forms.ComboBox
    Friend WithEvents lbl11 As System.Windows.Forms.Label
    Friend WithEvents txtEmployeeNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtdatee As System.Windows.Forms.DateTimePicker
    Friend WithEvents lbl12 As System.Windows.Forms.Label
    Friend WithEvents btn1 As System.Windows.Forms.Button
End Class
