﻿Imports MySql.Data.MySqlClient
Public Class NewAccount

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lbl2.Click

    End Sub

    Private Sub Label1_Click_1(sender As Object, e As EventArgs) Handles lbl6.Click

    End Sub


    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        If txtName.Text = "" Then
            MsgBox("Fill in the space")
            txtName.Focus()

        End If


        If txtSurname.Text = "" Then
            MsgBox("Fill in the space")
            txtSurname.Focus()

        End If


        If txtPhysicaladdress.Text = "" Then
            MsgBox("Fill in the space")
            txtPhysicaladdress.Focus()
        End If


        If txtEmail.Text = "" Then
            MsgBox("Fill in the space")
            txtEmail.Focus()
        End If


        If txtTelephone.Text = "" Then
            MsgBox("Fill in the space")
            txtTelephone.Focus()

        End If


        If txtDOB.Text = "" Then
            MsgBox("Fill in the space")
            txtDOB.Focus()

        End If


        If radMale.Checked = False And radFemale.Checked = False Then


            MsgBox("Please check Male or Female")

        End If

        If txtPosition.Text = "" Then
            MsgBox("Fill in the space")
            txtPosition.Focus()

        End If

        If txtBranch.Text = "" Then
            MsgBox("Fill in the space")
            txtBranch.Focus()
        End If



        If cmb1.Text = "" Then
            MsgBox("Fill in the space")
            cmb1.Focus()

        End If

        If txtCity.Text = "" Then
            MsgBox("Fill in the space")
            txtCity.Focus()
        End If

        If cmb2.Text = "" Then
            MsgBox("Fill in the space")
            cmb2.Focus()
        End If

        If txtEmployeeNumber.Text = "" Then
            MsgBox("Fill in the space")
            txtEmployeeNumber.Focus()
        End If

        If txtdatee.Text = "" Then
            MsgBox("Fill in the space")
            txtdatee.Focus()
        End If


        EppyModule.SaveUser()

    End Sub

    Private Sub Texbox1_TextChanged(sender As Object, e As EventArgs) Handles lbl1.TextChanged

    End Sub

    Private Sub NewAccount_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim CommandObject As MySqlCommand
        Dim sqlString As String
        Dim DataReader As MySqlDataReader
        sqlString = "Select * FROM eppy"
        CommandObject = New MySqlCommand(sqlString, EppyConnection())
        DataReader = CommandObject.ExecuteReader
        While (DataReader.Read())
            'cmb1.Items.Add(DataReader.GetString("Status"))
        End While
    End Sub
End Class