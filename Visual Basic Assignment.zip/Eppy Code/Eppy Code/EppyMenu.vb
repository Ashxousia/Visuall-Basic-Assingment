﻿Public Class EppyMenu



    Private Sub NewAccountToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewAccountToolStripMenuItem.Click
        NewAccount.Show()
    End Sub
End Class