﻿Public Class EppyLogin

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lbl1.Click

    End Sub

    Private Sub EppyLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
       

    End Sub

    Private Sub Btn1_Click(sender As Object, e As EventArgs) Handles Btn1.Click
        If txtusername.Text = "eppy" And txtpassword.Text = "12345" Then

            MsgBox("Correct Details!")
            Me.Hide()
            EppyMenu.Show()







        Else
            MsgBox("Wrong Password")
        End If
    End Sub
End Class
