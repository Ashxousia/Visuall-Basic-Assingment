﻿Imports System.Convert
Imports MySql.Data.MySqlClient


Public Module EppyModule

    Public Sub Connection()
        Dim connectionString As String
        Dim eppyConn As New MySqlConnection
        connectionString = "server=localhost;userid=root;database=eppy_db"
        eppyConn.ConnectionString = connectionString
        Try
            eppyConn.Open()

        Catch ex As MySqlException
            MsgBox(ex.Message)

        End Try

    End Sub
    Function EppyConnection() As MySqlConnection
        Dim connectionString As String
        Dim eppyConn As New MySqlConnection
        connectionString = "server=localhost;userid=root;database=eppy_db"
        eppyConn.ConnectionString = connectionString
        Try
            eppyConn.Open()
            MsgBox("Connected!!")
        Catch ex As MySqlException
            MsgBox(ex.Message)

        End Try
        Return eppyConn
    End Function
    Public Sub SaveUser()


        Dim Name As String
        Dim Surname As String
        Dim PhysicalAddress As String
        Dim Email As String
        Dim Telephone As Integer
        Dim DOB As Date
        Dim sex As String
        Dim Position As String
        Dim Branch As String
        Dim Employmentstatus As String
        Dim City As String
        Dim Country As String
        Dim EmployeeNumber As Integer
        Dim Datee As Date

        Dim cmd As New MySqlCommand
        Dim sqlString As String

        With NewAccount
            Name = .txtName.Text
            Surname = .txtSurname.Text
            PhysicalAddress = .txtPhysicaladdress.Text
            Email = .txtEmail.Text
            Telephone = .txtTelephone.Text
            DOB = Format(.txtDOB.Value, "yyyy-MM-dd")
            If .radMale.Checked Then
                sex = "Male"
            Else
                sex = "Female"
            End If
            Position = .txtPosition.Text
            Branch = .txtBranch.Text
            Employmentstatus = .cmb1.Text
            City = .txtCity.Text
            Country = .cmb2.Text
            EmployeeNumber = .txtEmployeeNumber.Text
            Datee = Format(.txtdatee.Value, "yyyy-MM-dd")


        End With
        sqlString = "INSERT INTO eppy VALUES('" & Name & "','" & _
            Surname & "','" & PhysicalAddress & "'," & Email & "," & Telephone & ",'" & _
        DOB & "','" & sex & "'," & Position & "," & Branch & "," & Employmentstatus & "," & City & "," & Country & "," & EmployeeNumber & "," & Datee & ")"

        With cmd
            .Connection = EppyConnection()
            .CommandText = sqlString
            .CommandType = CommandType.Text
            .ExecuteNonQuery()
        End With
        MsgBox("User Saved in System!!")

        sqlString = "select* FROM eppy('" & Name & "';'" & PhysicalAddress & "')"
        With cmd
            .Connection = EppyConnection()
            .CommandText = sqlString
            .CommandType = CommandType.Text
            '.ExecuteNonQuery()
        End With
    End Sub
End Module
